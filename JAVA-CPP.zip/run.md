1. `cd bin` (On both windows)

2. `java Server` (On one window)

3. `java Client` (On other window) 